// import React from 'react'
import { ListCourse } from "./components/Bai1";
import { Calcution } from "./components/Bai2";
export default function App() {
  return (
    <div>
      <ListCourse></ListCourse>
      <Canculation></Canculation>
    </div>
  )
}
